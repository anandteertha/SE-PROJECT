class CartItem:
    UserId: int
    MenuItemId: int
    Quantity: int
    ExtraNote: str