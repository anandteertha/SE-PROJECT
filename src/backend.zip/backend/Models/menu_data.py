class MenuData:
    def __init__(self):
        self.cart_items = []
        self.dietary_preferences = []
        self.menu_items = []
        self.user_menu_settings = []
        self.menu_categories = []